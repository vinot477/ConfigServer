package com.capgemini.party.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.party.configuration.PartyClient;
import com.party.GetPartyResponse;


@RestController
public class PartyController {
	@Autowired
	public PartyClient partyClient;

	@RequestMapping("/party")
	public GetPartyResponse getPartyDetails(@RequestParam("accountId") String accountId) {

		GetPartyResponse response = partyClient.getPatyByAccountid(accountId);
		return response;
	}
}
