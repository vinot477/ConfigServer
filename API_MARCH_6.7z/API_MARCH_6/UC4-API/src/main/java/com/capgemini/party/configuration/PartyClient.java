package com.capgemini.party.configuration;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.party.GetPartyRequest;
import com.party.GetPartyResponse;

public class PartyClient extends WebServiceGatewaySupport {
	
	@HystrixCommand(fallbackMethod="connectionHandler")
	public GetPartyResponse getPatyByAccountid(String accountId) {

		GetPartyRequest getPartyRequest = new GetPartyRequest();
		getPartyRequest.setAccountid(accountId);

		GetPartyResponse getPartyResponse = (GetPartyResponse) getWebServiceTemplate()
				.marshalSendAndReceive("http://partydetailssoap.cfapps.io:80/ws", getPartyRequest);
		return getPartyResponse;

	}
	
	public String connectionHandler() {
		return "The Requested Party Service is down!!!!!!!!";
	}

}
