package com.example.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.rest.wsdl.StudentDetailsResponse;

@SpringBootApplication
@RestController
public class RestApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApplication.class, args);
	}
	@Bean
	CommandLineRunner lookup(StudentClient StudentClient) {
		return args -> {
			String country = "Sukesh";

			if (args.length > 0) {
				country = args[0];
			}
			StudentDetailsResponse response = StudentClient.getStudent(country);
			
		};
	}
	@Autowired
	public StudentClient studentClient;
	@RequestMapping("/rest")
	public StudentDetailsResponse getRes() {
		String name="Sukesh";
		
		 
		StudentDetailsResponse response = studentClient.getStudent(name);
				return response;
	}

}

