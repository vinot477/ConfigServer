package com.example.rest;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.example.rest.wsdl.StudentDetailsRequest;
import com.example.rest.wsdl.StudentDetailsResponse;

public class StudentClient extends WebServiceGatewaySupport {
	
	public StudentDetailsResponse getStudent(String student) {

		StudentDetailsRequest request = new StudentDetailsRequest();
		request.setName(student);

		StudentDetailsResponse response = (StudentDetailsResponse) getWebServiceTemplate()
				.marshalSendAndReceive("http://localhost:8080/service", request);

		return response;
	}

}
