package com.capgemini.payment.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.payment.Repository.PaymentRepository;
import com.capgemini.payment.exception.CustomPaymentException;
import com.capgemini.payment.model.Request;

@RestController
public class PaymentsController {
	@Autowired
	private PaymentRepository paymentRepository;

	@PostMapping(value = "/domestic-scheduled-payment-consents", consumes = "application/json")
	@ResponseBody
	public ResponseEntity<Request> savePayment(@Valid @RequestBody Request request) throws CustomPaymentException {
		Request response = paymentRepository.savePayment(request);
		return new ResponseEntity<Request>(response, HttpStatus.CREATED);

	}

}
