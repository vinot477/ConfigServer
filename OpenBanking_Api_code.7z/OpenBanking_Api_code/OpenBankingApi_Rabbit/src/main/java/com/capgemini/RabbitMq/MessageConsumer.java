package com.capgemini.RabbitMq;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import java.io.IOException;
@Component
public class MessageConsumer {    
  @RabbitListener(queues = "SAMPLE-INPUT")    
  public void handleForwardEngineeringRequest(String request) throws IOException {        
	System.out.println(request);
	  
  }
}