package com.capgemini.RabbitMq;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RabbitController {
	private final MessageProducer messageProducer;

	public RabbitController(MessageProducer messageProducer) {
		this.messageProducer = messageProducer;
	}

	
	@PostMapping("/testRabbit")
	public String sendMessage(@RequestParam String request) {
		messageProducer.sendMessage(request);
		return "Message has been sent successfully to Rabbit Mq";
	}

	@Bean
	public Queue queue() {
		return new Queue("SAMPLE-INPUT");
	}
}