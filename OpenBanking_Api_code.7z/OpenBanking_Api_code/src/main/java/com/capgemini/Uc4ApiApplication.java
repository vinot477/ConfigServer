package com.capgemini;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.ComponentScan;
@EnableCircuitBreaker
@RefreshScope
@EnableEurekaClient
@SpringBootApplication
@ComponentScan(basePackages="com.capgemini")
public class Uc4ApiApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(Uc4ApiApplication.class, args);
	}
}
