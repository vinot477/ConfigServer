package com.capgemini.party.controller;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.party.configuration.PartyClient;
import com.party.GetPartyResponse;


@RestController
@Validated
public class PartyController {
	@Autowired
	public PartyClient partyClient;

	@RequestMapping(value="/party",produces="application/json")
	public GetPartyResponse getPartyDetails(@Valid @Pattern(regexp = "[0-9]+", message = "accountId should be of digits only")@RequestParam("accountId") String accountId) {

		GetPartyResponse response = (GetPartyResponse) partyClient.getPartyByAccountid(accountId);
		return response;
	}
}
