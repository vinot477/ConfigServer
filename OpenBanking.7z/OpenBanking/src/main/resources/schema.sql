CREATE TABLE `account` (
  `identification` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `scheme_name` varchar(255) NOT NULL,
  PRIMARY KEY (`identification`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `consents` (
  `consent_id` int(11) NOT NULL,
  `amount` double DEFAULT NULL,
  `creation_date_time` datetime DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `payment_context_code` varchar(255) DEFAULT NULL,
  `permission` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `requested_execution_date` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_update_date_time` datetime DEFAULT NULL,
  `unstructured` varchar(255) DEFAULT NULL,
  `creditor_id` varchar(255) DEFAULT NULL,
  `debtor_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`consent_id`),
  KEY `FK4qqv0a4yjb6oav01fq524gbfx` (`creditor_id`),
  KEY `FKg12cnn76prpwxpa11lu1sc48j` (`debtor_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
