package com.capgemini.party.configuration;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.party.GetPartyRequest;
import com.party.GetPartyResponse;

public class PartyClient extends WebServiceGatewaySupport {
	public GetPartyResponse getPartyByAccountid(String accountId) {

		GetPartyRequest getPartyRequest = new GetPartyRequest();
		getPartyRequest.setAccountid(accountId);

		return (GetPartyResponse) getWebServiceTemplate()
				.marshalSendAndReceive("http://partydetailssoap.cfapps.io:80/ws", getPartyRequest);

		

	}

}
