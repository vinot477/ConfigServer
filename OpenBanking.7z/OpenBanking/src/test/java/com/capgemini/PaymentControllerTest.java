package com.capgemini;

import static org.junit.Assert.assertEquals;

import javax.validation.ConstraintViolationException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.capgemini.payment.controller.PaymentsController;
import com.capgemini.payment.model.Account;
import com.capgemini.payment.model.Data;
import com.capgemini.payment.model.Initiation;
import com.capgemini.payment.model.InstructedAmount;
import com.capgemini.payment.model.RemittanceInformation;
import com.capgemini.payment.model.Request;
import com.capgemini.payment.model.Risk;

@SpringBootTest
@ContextConfiguration
@AutoConfigureMockMvc
@RunWith(SpringJUnit4ClassRunner.class)
public class PaymentControllerTest {

	@Autowired
	PaymentsController paymentsController;

	@Test
	public void savePayment() {
		Account creditAccount = new Account("UK.OBIE.SortCodeAccountNumber", "08080021325698", "Tom Kirkman");
		Account debitAccount = new Account("UK.OBIE.SortCodeAccountNumber", "11280001234567", "Andrea Frost");
		InstructedAmount instructedAmount = new InstructedAmount(200.00, "GBP");
		RemittanceInformation remittanceInformation = new RemittanceInformation("DSR-037", "Internal ops code 5120103");
		java.util.Date utilDate = new java.util.Date();
		java.sql.Timestamp time = new java.sql.Timestamp(utilDate.getTime());
		Initiation initiation = new Initiation(time, instructedAmount, creditAccount, debitAccount,
				remittanceInformation);
		Data data = new Data();
		data.setPermission("Create");
		data.setInitiation(initiation);
		Risk risk = new Risk("PartyToParty");
		Request request = new Request();
		request.setData(data);
		request.setRisk(risk);

		ResponseEntity<Request> result = paymentsController.savePayment(request);

		assertEquals(201, result.getStatusCodeValue());
	}

	@Test
	public void handleBadRequest() {
		Account creditAccount = new Account("UK.OBIE.SortCodeAccountNumber", "0808002132569", "Tom Kirkman");
		Account debitAccount = new Account("UK.OBIE.SortCodeAccountNumber", "11280001234567", "Andrea Frost");
		InstructedAmount instructedAmount = new InstructedAmount(200.00, "GBP");
		RemittanceInformation remittanceInformation = new RemittanceInformation("DSR-037", "Internal ops code 5120103");
		java.util.Date utilDate = new java.util.Date();
		java.sql.Timestamp time = new java.sql.Timestamp(utilDate.getTime());
		Initiation initiation = new Initiation(time, instructedAmount, creditAccount, debitAccount,
				remittanceInformation);
		Data data = new Data();
		data.setPermission("Create");
		data.setInitiation(initiation);
		Risk risk = new Risk("PartyToParty");
		Request request = new Request();
		request.setData(data);
		request.setRisk(risk);
		try {
			paymentsController.savePayment(request);
		} catch (ConstraintViolationException ex) {

			assertEquals(true, ex.getMessage().contains("identification should be of 14 digits"));
		}
	}

	@Test
	public void getConsentId() {
		Account creditAccount = new Account("UK.OBIE.SortCodeAccountNumber", "0808002132569", "Tom Kirkman");
		Account debitAccount = new Account("UK.OBIE.SortCodeAccountNumber", "11280001234567", "Andrea Frost");
		InstructedAmount instructedAmount = new InstructedAmount(200.00, "GBP");
		RemittanceInformation remittanceInformation = new RemittanceInformation("DSR-037", "Internal ops code 5120103");
		java.util.Date utilDate = new java.util.Date();
		java.sql.Timestamp time = new java.sql.Timestamp(utilDate.getTime());
		Initiation initiation = new Initiation(time, instructedAmount, creditAccount, debitAccount,
				remittanceInformation);
		Data data = new Data();
		data.setPermission("Create");
		data.setInitiation(initiation);
		Risk risk = new Risk("PartyToParty");
		Request request = new Request();
		request.setData(data);
		request.setRisk(risk);

		ResponseEntity<Request> result = paymentsController.savePayment(request);

		assertEquals(true, result.getBody().getData().getConsentId() != null);
	}

}
