package com.domestic;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.domestic.Repository.PaymentRepository;
import com.domestic.model.Request;

@RestController
public class PaymentsController {
	@Autowired
	private PaymentRepository paymentRepository;
	
	@PostMapping("/domestic-scheduled-payment-consents")
	@ResponseBody
	public  ResponseEntity<Request> save(@Valid @RequestBody Request request) {
		Request response=paymentRepository.savePayments(request);
		 return new ResponseEntity<Request>(response,HttpStatus.CREATED);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@GetMapping("/domestic-scheduled-payment-consents")
	public  String save1(){
		
		 return "Hello...";
		
	}
	
}
