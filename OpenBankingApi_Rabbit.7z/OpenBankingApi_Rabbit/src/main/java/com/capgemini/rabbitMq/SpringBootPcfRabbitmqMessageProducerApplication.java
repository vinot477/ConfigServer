package com.capgemini.rabbitMq;

import org.springframework.amqp.core.Queue;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SpringBootPcfRabbitmqMessageProducerApplication {
	private final MessageProducer messageProducer;

	public SpringBootPcfRabbitmqMessageProducerApplication(MessageProducer messageProducer) {
		this.messageProducer = messageProducer;
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPcfRabbitmqMessageProducerApplication.class, args);
	}

	@PostMapping("/testRabbit")
	public String sendMessage(@RequestParam String request) {
		messageProducer.sendMessage(request);
		return "Message has been sent successfully to Rabbit Mq";
	}

	@Bean
	public Queue queue() {
		return new Queue("SAMPLE-INPUT");
	}
}