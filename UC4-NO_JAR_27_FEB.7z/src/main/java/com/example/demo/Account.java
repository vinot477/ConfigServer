package com.example.demo;

public class Account {
	private String schemeName;
	private String identification;
	private String name;

	public Account() {
		super();
	}

	public Account(String schemeName, String identification, String name) {
		super();
		this.schemeName = schemeName;
		this.identification = identification;
		this.name = name;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getIdentification() {
		return identification;
	}

	public void setIdentification(String identification) {
		this.identification = identification;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
