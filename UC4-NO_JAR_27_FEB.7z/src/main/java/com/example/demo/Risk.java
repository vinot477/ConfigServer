package com.example.demo;

public class Risk {
	private String paymentContextCode;

	public Risk() {
		super();
	}

	public Risk(String paymentContextCode) {
		super();
		this.paymentContextCode = paymentContextCode;
	}

	public String getPaymentContextCode() {
		return paymentContextCode;
	}

	public void setPaymentContextCode(String paymentContextCode) {
		this.paymentContextCode = paymentContextCode;
	}

}
