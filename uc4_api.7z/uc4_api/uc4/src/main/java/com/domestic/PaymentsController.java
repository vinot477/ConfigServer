package com.domestic;

import javax.validation.Valid;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.domestic.Repository.PaymentRepository;
import com.domestic.model.Account;
import com.domestic.model.Data;
import com.domestic.model.Initiation;
import com.domestic.model.InstructedAmount;
import com.domestic.model.RemittanceInformation;
import com.domestic.model.Request;
import com.domestic.model.Risk;

@RestController
public class PaymentsController {
	@Autowired
	private PaymentRepository paymentRepository;
	
	@PostMapping("/")
	@ResponseBody
	public  ResponseEntity<Request> save(@Valid @RequestBody Request request) {
		Request response=paymentRepository.saveJpa(request);
		 HttpHeaders responseHeader = new HttpHeaders();
		 return new ResponseEntity<Request>(response,responseHeader,HttpStatus.CREATED);
		
	}
	@GetMapping("/get")
	@ResponseBody
	public  Request get() {
		java.util.Date utilDate = new java.util.Date();
		java.sql.Timestamp sq = new java.sql.Timestamp(utilDate.getTime());
		Initiation i=new Initiation();
		i.setRequestedExecutionDate(sq);
		InstructedAmount instructedAmount=new InstructedAmount(500.00, "INR");
		Account debtor=new Account("debit", "123", "vino");
		Account credtor=new Account("credit", "345", "biswajit");
		RemittanceInformation remittanceInformation=new RemittanceInformation("DSR-037","Internal ops code 5120103");
		i.setInstructedAmount(instructedAmount);
		i.setDebtorAccount(debtor);
		i.setCreditorAccount(credtor);
		i.setRemittanceInformation(remittanceInformation);
		
		Data d=new Data(100, "s", "s", sq, sq, i);
		Risk r1=new Risk("risk");
		Request r=new Request();
		r.setData(d);
		r.setRisk(r1);
		return r;
	}
}
