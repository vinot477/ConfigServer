package com.domestic.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;

import javax.persistence.RollbackException;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.domestic.model.*;
import com.domestic.model.Data;
import com.domestic.model.RemittanceInformation;
import com.domestic.model.Request;
import com.domestic.model.Risk;

@Repository
public class PaymentRepository {

	private final JdbcTemplate jdbcTemplate;

	@Autowired
	public PaymentRepository(JdbcTemplate template) {
		this.jdbcTemplate = template;
	}

	private final String SQL_INSERT_CONSENTS = "INSERT INTO consents(permission,status,creationDateTime,statusUpdateDateTime,requestedExecutionDate,amount,currency,reference,unstructured,paymentContextCode,creditorId,debitoriId) values(?,?,?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_INSERT_ACCOUNT = "INSERT INTO account(schemeName, identification,name) VALUES (?,?,?)";

	public Request save(Request request) {

		Data data = request.getData();
		Risk risk = request.getRisk();
		Initiation initiation = data.getInitiation();
		InstructedAmount instructedAmount = initiation.getInstructedAmount();
		Account debtorAccount = initiation.getDebtorAccount();
		Account creditorAccount = initiation.getCreditorAccount();
		RemittanceInformation remittanceInformation = initiation.getRemittanceInformation();
		java.util.Date utilDate = new java.util.Date();
		java.sql.Timestamp time = new java.sql.Timestamp(utilDate.getTime());
		data.setCreationDateTime(time);
		data.setStatusUpdateDateTime(time);
		data.setStatus("AwaitingAuthorisation");

		this.jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(SQL_INSERT_ACCOUNT);

			ps.setString(1, debtorAccount.getSchemeName());
			ps.setString(2, debtorAccount.getIdentification());
			ps.setString(3, debtorAccount.getName());
			return ps;
		});

		this.jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(SQL_INSERT_ACCOUNT);

			ps.setString(1, creditorAccount.getSchemeName());
			ps.setString(2, creditorAccount.getIdentification());
			ps.setString(3, creditorAccount.getName());
			return ps;
		});

		Connection connection;
		Integer generatedKey = 0;
		try {
			connection = this.jdbcTemplate.getDataSource().getConnection();
			PreparedStatement ps = connection.prepareStatement(SQL_INSERT_CONSENTS, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, data.getPermission());
			ps.setString(2, data.getStatus());
			ps.setTimestamp(3, data.getCreationDateTime());
			ps.setTimestamp(4, data.getStatusUpdateDateTime());
			ps.setTimestamp(5, initiation.getRequestedExecutionDate());
			ps.setDouble(6, instructedAmount.getAmount());
			ps.setString(7, instructedAmount.getCurrency());
			ps.setString(8, remittanceInformation.getReference());
			ps.setString(9, remittanceInformation.getUnstructured());
			ps.setString(10, risk.getPaymentContextCode());
			ps.setString(11, creditorAccount.getIdentification());
			ps.setString(12, debtorAccount.getIdentification());
			ps.execute();
			ResultSet rs = ps.getGeneratedKeys();

			if (rs.next()) {
				generatedKey = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		data.setConsentId(generatedKey);
		Request response = new Request();
		response.setData(data);
		response.setRisk(risk);
		return response;
	}

	@Autowired
	private ConsentsRepository consentsRepository;

	@Autowired
	private AccountRepository accountRepository;

	public Request saveJpa(Request request) {
	
		Data data = request.getData();
		Risk risk = request.getRisk();
		Initiation initiation = data.getInitiation();
		InstructedAmount instructedAmount = initiation.getInstructedAmount();
		Account debtorAccount = initiation.getDebtorAccount();
		Account creditorAccount = initiation.getCreditorAccount();
		RemittanceInformation remittanceInformation = initiation.getRemittanceInformation();
		java.util.Date utilDate = new java.util.Date();
		java.sql.Timestamp time = new java.sql.Timestamp(utilDate.getTime());
		data.setCreationDateTime(time);
		data.setStatusUpdateDateTime(time);
		data.setStatus("AwaitingAuthorisation");

		Consents consents = new Consents();
		consents.setPermission(data.getPermission());
		consents.setStatus(data.getStatus());
		consents.setCreationDateTime(data.getCreationDateTime());
		consents.setStatusUpdateDateTime(data.getStatusUpdateDateTime());
		consents.setRequestedExecutionDate(initiation.getRequestedExecutionDate());
		consents.setAmount(instructedAmount.getAmount());
		consents.setCurrency(instructedAmount.getCurrency());
		consents.setReference(remittanceInformation.getReference());
		consents.setUnstructured(remittanceInformation.getUnstructured());
		consents.setPaymentContextCode(risk.getPaymentContextCode());
		consents.setCreditorAccount(creditorAccount);
		consents.setDebtorAccount(debtorAccount);

		Account ca = accountRepository.save(creditorAccount);
		Account da = accountRepository.save(debtorAccount);
		consents.setCreditorAccount(ca);
		consents.setDebtorAccount(da);
		Consents responseConsents = consentsRepository.save(consents);
		data.setConsentId(responseConsents.getConsentId());

		Request response = new Request();
		response.setData(data);
		response.setRisk(risk);
		return response;

	}

}
