package com.capgemini.party.configuration;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.party.GetPartyRequest;
import com.party.GetPartyResponse;

public class PartyClient extends WebServiceGatewaySupport {
	@HystrixCommand(fallbackMethod = "handler")
	public Object getPartyByAccountid(String accountId) {

		GetPartyRequest getPartyRequest = new GetPartyRequest();
		getPartyRequest.setAccountid(accountId);

		GetPartyResponse getPartyResponse = (GetPartyResponse) getWebServiceTemplate()
				.marshalSendAndReceive("http://partydetailssoap.cfapps.io:80/ws", getPartyRequest);
		return getPartyResponse;

	}

	@SuppressWarnings("unused")
	public Object handler(String accountId) {
		
		return "SERVER DOWN !!!!!!!!!";
	}

}
