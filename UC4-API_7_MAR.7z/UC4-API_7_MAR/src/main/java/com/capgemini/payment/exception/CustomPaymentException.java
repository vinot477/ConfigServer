package com.capgemini.payment.exception;

public class CustomPaymentException extends Exception{
	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public CustomPaymentException() {
		super();
	}

	public CustomPaymentException(String message) {
		super();
		this.message = message;
	}

}
