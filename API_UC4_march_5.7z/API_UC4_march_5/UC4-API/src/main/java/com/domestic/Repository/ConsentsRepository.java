package com.domestic.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.domestic.model.Consents;

public interface ConsentsRepository extends JpaRepository<Consents,Integer> {

}
