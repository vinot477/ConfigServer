package com.domestic;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
@SpringBootApplication
@ComponentScan(basePackages="com.domestic")
public class Uc4ApiApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(Uc4ApiApplication.class, args);
	}
}
