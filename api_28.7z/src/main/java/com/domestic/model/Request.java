package com.domestic.model;

import org.springframework.stereotype.Component;

@Component
public class Request {

	private Data data;
	private Risk risk;
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public Risk getRisk() {
		return risk;
	}
	public void setRisk(Risk risk) {
		this.risk = risk;
	}
}
