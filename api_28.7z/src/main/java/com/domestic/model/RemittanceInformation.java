package com.domestic.model;

import org.springframework.stereotype.Component;

@Component
public class RemittanceInformation {
	private String reference;
	private String unstructured;

	public RemittanceInformation() {
		super();
	}

	public RemittanceInformation(String reference, String unstructured) {
		super();
		this.reference = reference;
		this.unstructured = unstructured;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getUnstructured() {
		return unstructured;
	}

	public void setUnstructured(String unstructured) {
		this.unstructured = unstructured;
	}

}
